package student.management;

import java.util.ArrayList;

public class Student {
    private String name;
    private int studentID;
    private ArrayList<String> courses;
    private double balance;
    private static int idCounter = 10000;

    public Student(String name) {
        this.name = name;
        this.studentID = generateStudentID();
        this.balance = 60000;  // fixed fees
        this.courses = new ArrayList<>();
    }

    private int generateStudentID() {
        return idCounter++;
    }

    public int getStudentID() {
        return studentID;
    }

    public String getName() {
        return name;
    }

    public void enrollCourse(String course) {
        courses.add(course);
        System.out.println(name + " enrolled in " + course);
    }

    public void viewBalance() {
        System.out.println("Balance for " + name + " (ID: " + studentID + "): ₹" + balance);
    }

    public void payTuition(double amount) {
        if (amount >= balance) {
            System.out.println(name + " paid ₹" + balance + ". Tuition fully paid.");
            balance = 0;
        } else {
            balance -= amount;
            System.out.println(name + " paid ₹" + amount + ". Remaining balance: ₹" + balance);
        }
    }

    public void showStatus() {
        System.out.println("\nStudent Name: " + name);
        System.out.println("Student ID: " + studentID);
        System.out.println("Enrolled Courses: " + courses);
        System.out.println("Balance: ₹" + balance + "\n");
    }
}
