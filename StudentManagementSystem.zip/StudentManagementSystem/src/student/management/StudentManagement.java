package student.management;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagement {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        while (true) {
            System.out.println("\nStudent Management System Menu:");
            System.out.println("1. Add Student");
            System.out.println("2. Enroll in Course");
            System.out.println("3. View Balance");
            System.out.println("4. Pay Tuition Fees");
            System.out.println("5. Show Student Status");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	System.out.print("Enter student name: ");
                	String name = scanner.nextLine();
                	Student newStudent = new Student(name);
                	students.add(newStudent);
                	System.out.println("Student " + name + " added successfully with ID: " + newStudent.getStudentID());
                    break;

                case 2:
                    System.out.print("Enter Student ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Course Name: ");
                    String course = scanner.nextLine();
                    Student foundStudent = findStudentByID(students, id);
                    if (foundStudent != null) {
                        foundStudent.enrollCourse(course);
                    } else {
                        System.out.println("Student ID not found!");
                    }
                    break;

                case 3:
                    System.out.print("Enter Student ID: ");
                    id = scanner.nextInt();
                    foundStudent = findStudentByID(students, id);
                    if (foundStudent != null) {
                        foundStudent.viewBalance();
                    } else {
                        System.out.println("Student ID not found!");
                    }
                    break;

                case 4:
                    System.out.print("Enter Student ID: ");
                    id = scanner.nextInt();
                    System.out.print("Enter Amount: ");
                    int amount = scanner.nextInt();
                    foundStudent = findStudentByID(students, id);
                    if (foundStudent != null) {
                        foundStudent.payTuition(amount);
                    } else {
                        System.out.println("Student ID not found!");
                    }
                    break;

                case 5:
                    System.out.print("Enter Student ID: ");
                    id = scanner.nextInt();
                    foundStudent = findStudentByID(students, id);
                    if (foundStudent != null) {
                        foundStudent.showStatus();
                    } else {
                        System.out.println("Student ID not found!");
                    }
                    break;

                case 6:
                    System.out.println("Exiting the system...");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }

    
    private static Student findStudentByID(ArrayList<Student> students, int id) {
        for (Student student : students) {
            if (student.getStudentID() == id) {
                return student;
            }
        }
        return null;
    }

}
